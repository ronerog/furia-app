// src/services/api.ts
import axios from 'axios';
import { API_URL } from '../config';

// Cria uma instância do axios com URL base e configurações
const api = axios.create({
  baseURL: API_URL,
  timeout: 10000, // 10 segundos
  headers: {
    'Content-Type': 'application/json'
  }
});

// Interceptador para incluir o token em todas as requisições
api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// Interceptador para tratamento global de erros
api.interceptors.response.use(
  response => {
    return response;
  },
  error => {
    // Se o erro for de autenticação (401), tente renovar o token ou faça logout
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;