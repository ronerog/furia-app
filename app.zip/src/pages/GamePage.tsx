import UnderConstruction from '../components/UnderConstruction';

const GamePage = () => {
    return <UnderConstruction pageName="Detalhes do Jogo" />;
  };
  
  export default GamePage;