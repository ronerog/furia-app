import UnderConstruction from '../components/UnderConstruction';

const Streams = () => {
    return <UnderConstruction pageName="Detalhes do Jogo" />;
  };
  
  export default Streams;