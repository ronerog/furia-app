import UnderConstruction from '../components/UnderConstruction';

const Matches = () => {
    return <UnderConstruction pageName="Detalhes do Jogo" />;
  };
  
  export default Matches;