import UnderConstruction from '../components/UnderConstruction';

const NotFound = () => {
    return <UnderConstruction pageName="Detalhes do Jogo" />;
  };
  
  export default NotFound;