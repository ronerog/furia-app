import UnderConstruction from '../components/UnderConstruction';

const NewsItem = () => {
    return <UnderConstruction pageName="Detalhes do Jogo" />;
  };
  
  export default NewsItem;