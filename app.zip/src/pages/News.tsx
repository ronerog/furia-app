import UnderConstruction from '../components/UnderConstruction';

const News = () => {
    return <UnderConstruction pageName="Detalhes do Jogo" />;
  };
  
  export default News;