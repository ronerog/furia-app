// src/config.ts
export const API_URL = 'https://api.furia.gg'; // URL da API em produção
export const SOCKET_URL = 'https://socket.furia.gg'; // URL do Socket.io em produção

// // Em ambiente de desenvolvimento, use URLs locais
// if (process.env.NODE_ENV === 'development') {
//   // API_URL = 'http://localhost:5000';
//   // SOCKET_URL = 'http://localhost:5000';
// }