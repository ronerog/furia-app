// src/config.ts
export const API_URL = 'http://localhost:5000/api';
export const SOCKET_URL = 'http://localhost:5000';

// // Em ambiente de desenvolvimento, use URLs locais
// if (process.env.NODE_ENV === 'development') {
//   // API_URL = 'http://localhost:5000';
//   // SOCKET_URL = 'http://localhost:5000';
// }