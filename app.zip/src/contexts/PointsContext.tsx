/* eslint-disable prefer-const */
// src/contexts/PointsContext.tsx - versão corrigida com chamadas de API

import { createContext, useState, useEffect, useContext, ReactNode } from 'react';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import axios from 'axios';
import { AuthContext } from './AuthContext';
import { Activity, Reward } from '../types';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { API_URL } from '../config';
import api from '../services/api';

interface PointsContextType {
  points: number;
  rewards: Reward[];
  activities: Activity[];
  addPoints: (amount: number, activityType: string) => Promise<void>;
  redeemReward: (rewardId: string, shippingAddress: string) => Promise<unknown>;
}

interface PointsProviderProps {
  children: ReactNode;
}

export const PointsContext = createContext<PointsContextType>({
  points: 0,
  rewards: [],
  activities: [],
  addPoints: async () => {},
  redeemReward: async () => ({}),
});

export const PointsProvider = ({ children }: PointsProviderProps) => {
  const { isAuthenticated, user } = useContext(AuthContext);
  const [points, setPoints] = useState(0);
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);

  useEffect(() => {
    if (isAuthenticated && user) {
      setPoints(user.points || 0);
      loadRewards();
      loadActivities();
    }
  }, [isAuthenticated, user]);

  const loadRewards = async () => {
    try {
      const response = await api.get('/rewards');
      setRewards(response.data.data);
    } catch (err) {
      console.error('Erro ao carregar recompensas:', err);
    }
  };

  const loadActivities = async () => {
    if (!user) return;
    
    try {
      const response = await api.get(`/users/${user.id}/activities`);
      setActivities(response.data.data);
    } catch (err) {
      console.error('Erro ao carregar atividades:', err);
    }
  };

  let isAddingPoints = false;

  const addPoints = async (amount: number, activityType: string) => {
    if (isAddingPoints) return;
    if (!isAuthenticated || !user?.id) return;
  
    isAddingPoints = true;
    try {
      const response = await api.post(`/users/${user.id}/points`, {
        amount,
        activityType,
      });
      setPoints(response.data.totalPoints);
      await loadActivities();
    } catch (err) {
      console.error('Erro ao adicionar pontos:', err);
    } finally {
      isAddingPoints = false;
    }
  }; 

  const redeemReward = async (rewardId: string, shippingAddress: string) => {
    if (!isAuthenticated) {
      throw new Error('Usuário não autenticado');
    }
    
    if (!user || !user.id) {
      console.error('ID do usuário não está disponível');
      throw new Error('Não foi possível identificar o usuário');
    }
    
    if (!rewardId) {
      console.error('ID da recompensa não definido');
      throw new Error('ID da recompensa inválido');
    }
    
    try {
      console.log(`Resgatando recompensa ${rewardId} para o usuário ${user.id}`);
      
      const response = await api.post(`/users/${user.id}/redeem`, {
        rewardId,
        shippingAddress 
      });
      
      setPoints(response.data.remainingPoints);
      loadActivities();
      
      return response.data;
    } catch (err) {
      console.error('Erro ao resgatar recompensa:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (!isAuthenticated || !user?.id) {
      console.log('Usuário não está completamente autenticado para iniciar a contagem de pontos por tempo');
      return;
    }
  
    console.log(`Iniciando contagem de pontos por tempo para o usuário ${user.id}`);
  
    const interval = window.setInterval(() => {
      console.log(`Adicionando 5 pontos por tempo para o usuário ${user.id}`);
      addPoints(5, 'view_time');
    }, 60000);
  
    return () => {
      window.clearInterval(interval);
    };
  }, [isAuthenticated, user?.id]);

  return (
    <PointsContext.Provider
      value={{
        points,
        rewards,
        activities,
        addPoints,
        redeemReward
      }}
    >
      {children}
    </PointsContext.Provider>
  );
};